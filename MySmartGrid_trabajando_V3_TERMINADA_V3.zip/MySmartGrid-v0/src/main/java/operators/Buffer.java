package operators;

import energy.Consumo;
import energy.ConsumoPendiente;

public class Buffer {
	private int top, capacity; 
	private ConsumoPendiente vector[];
	private boolean vacio=false;
	
	Buffer(int i) {
		top=0;
		capacity=i;
		vector = new ConsumoPendiente[i];
	}
	synchronized public void liberarBuffer() {
		vacio=true;
		notifyAll();
	}
	
	synchronized public int getTop() {return top;}
	synchronized public boolean getVacio() {return vacio;}
	synchronized public void cambioVacio() {vacio=true;}
	
	synchronized public ConsumoPendiente extraer() {
		while(top==0&&!vacio) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		if(top==0&&vacio) {
			return null;
		}
		top--;
		ConsumoPendiente c=vector[top];
		notifyAll();
		
		return c;
	}
	
	synchronized public void insertar(ConsumoPendiente c) {
		while(top==capacity) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		vector[top]=c;
		top++;
		notifyAll();
		
	}
}
