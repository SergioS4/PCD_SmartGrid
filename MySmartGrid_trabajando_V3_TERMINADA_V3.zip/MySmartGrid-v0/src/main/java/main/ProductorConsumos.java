package main;

//import energy.RedEnergetica;
import energy.ZonaEnergetica;
import energy.Consumo;
import energy.ConsumoPendiente;

import java.util.List;


public class ProductorConsumos implements Runnable {
	private ZonaEnergetica z;
	private List<Consumo> consumos;
	public int getIdZona() {return z.getIdZona();}
	public int getNumConZona() { return consumos.size();}

	
	public ProductorConsumos(ZonaEnergetica zona, List<Consumo> c) {
		// TODO Auto-generated constructor stub
		this.z=zona;
		this.consumos=c;
	}
//	PRODUCTOR DE CONSUMOS
	public void run() {		
		for(Consumo c:consumos) {
			ConsumoPendiente cPend = new ConsumoPendiente(c);
			z.getCentroControl().getBuffer().insertar(cPend);
			cPend.esperar();
		}
//		z.getCentroControl().getBuffer().cambioVacio();
		z.cambioVacia();
		z.getCentroControl().getBuffer().liberarBuffer();
	}
}


