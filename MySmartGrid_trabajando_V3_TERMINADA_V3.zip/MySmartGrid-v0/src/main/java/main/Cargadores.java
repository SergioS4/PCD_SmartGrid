package main;

import energy.ZonaEnergetica;

public class Cargadores implements Runnable{
	private ZonaEnergetica z;
	public Cargadores(ZonaEnergetica zona) {
		this.z=zona;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(!z.getVacia()) {
			z.recargarEnergia();
		}
		
	}

}
