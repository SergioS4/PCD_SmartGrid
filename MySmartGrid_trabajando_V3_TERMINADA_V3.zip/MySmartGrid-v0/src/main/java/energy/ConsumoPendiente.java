package energy;

public class ConsumoPendiente {
	private Consumo consumo;
	private boolean terminado=false;
	public ConsumoPendiente (Consumo c) {
		this.consumo=c;
	}
	public Consumo getConsumo() { return consumo;}

	synchronized public void esperar() {
		while(!terminado) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	synchronized public void finaliza() {
		terminado=true;
		notifyAll();
	}
}
