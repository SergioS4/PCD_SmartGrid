package energy;

import operators.CentroControl;
import pcd.util.Ventana;
import storage.Bateria;

import java.awt.Color;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Objects;

import main.Config;

public class ZonaEnergetica {
    private final int idZona;
    private final CuentaEnergetica cuenta;
    private final Bateria bateria;
    private final CentroControl centroControl;
    private Ventana v;
    private boolean vacia=false; 
    private boolean cargada=true;

    public ZonaEnergetica(int idZona, CuentaEnergetica cuenta, Bateria bateria, CentroControl centroControl, Ventana _v) {
        this.idZona = idZona;
        this.cuenta = Objects.requireNonNull(cuenta);
        this.bateria = Objects.requireNonNull(bateria);
        this.centroControl = Objects.requireNonNull(centroControl);
        this.v = _v;
    }
    public int getIdZona() { return idZona; }
    public CuentaEnergetica getCuenta() { return cuenta; }
    public Bateria getBateria() { return bateria; }
    public CentroControl getCentroControl() { return centroControl; }
    synchronized public boolean getVacia() {return vacia;}
	synchronized public void cambioVacia() {vacia=true;}
    //public List<Consumo> getConsumo() { return consumoZona; }

    
    public synchronized String tramitarConsumo(Consumo c) {
        if (c.getZona() != idZona) {
            return "ERROR: consumo dirigido a zona " + c.getZona() + " pero tramitado en zona " + idZona;
        }

        v.traza (c.getIdConsumo()+" solicita: "+c.getTotalKWh(), Color.BLUE);
        while(bateria.getNivelActualKWh()<c.getTotalKWh()) {
        	cargada=false;
        	notifyAll();
        	try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        String resultado = centroControl.enviarTrabajo(c);
//		System.out.println("CONSUMO " +c.getIdConsumo()+ " tramitado con exito");
		notifyAll();
        return resultado;
    }
    
    public synchronized void recargarEnergia() {

        if (getIdZona() != idZona) {
            System.out.println("ERROR: Bateria de zona" + getIdZona() + " Se ha intendado cargar en la zona " + idZona);
        }
        while(cargada) {
        	try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        
        bateria.carga(Config.CAPACIDAD_BATERIA);
        cargada=true;
        notifyAll();

    }

	@Override
    public String toString() {
        return "ZonaEnergetica{idZona=" + idZona + ", cuenta=" + cuenta + ", bateria=" + bateria + "}";
    }
    
    public Ventana getVentana () {
    	return v;
    }
    
    public void traza (String s) {
    	v.traza(s);
    }
    
    public void traza (String s, Color color) {
    	v.traza(s,color);
    }


}
