package operators;

import java.util.Random;
import energy.Consumo;
import energy.ZonaEnergetica;

public class CentroControl {
    private ZonaEnergetica zona;
    Buffer buffer = new Buffer(5);

    public CentroControl() {
        
    }
    public Buffer getBuffer() {
		return buffer;
	}
    
    public void setZona(ZonaEnergetica zona) {
    	this.zona=zona;
    }

    public int getIdZona() { return zona.getIdZona(); }

    public String enviarTrabajo(Consumo c,double normal,double solar,double viento) {

    	Random r = new Random();
        // Simulamos un tiempo de tramitación del consumo
        try {
			Thread.sleep(r.nextInt(200));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
        double total = c.getTotalKWh();
        System.out.println("CONSUMO TOTAL --" +total);

        double suministrado = zona.getBateria().suministra(normal);
//        System.out.println("CONSUMO  --" +suministrado);
        suministrado+=zona.getBatEo().suministra(viento);
//        System.out.println("CONSUMO NORMAL --" +suministrado);
        suministrado+=zona.getBatSol().suministra(solar);
        System.out.println("CONSUMO  --" +suministrado);
        zona.getCuenta().anotaConsumo(suministrado);
        
        String resultado = (suministrado >= total)
                ? "OK: suministrados " + fmt(total) + " kWh"
                : "PARCIAL: suministrados " + fmt(suministrado) + " kWh (faltan " + fmt(total - suministrado) + " kWh)";
    	
        if(resultado.startsWith("OK")) traza ("Trabajo completado para: "+c.getIdConsumo());
        return resultado;
    }
    
    private String fmt(double x) {
        return String.format(java.util.Locale.ROOT, "%.2f", x);
    }

    public void traza(String msg) {
        System.out.println("[CentroControl Z" + zona.getIdZona() + "] " + msg);
    }
}
