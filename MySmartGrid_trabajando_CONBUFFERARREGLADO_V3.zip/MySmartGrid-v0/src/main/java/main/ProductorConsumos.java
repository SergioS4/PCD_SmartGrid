package main;

//import energy.RedEnergetica;
import energy.ZonaEnergetica;
import energy.Consumo;
import java.util.List;


public class ProductorConsumos implements Runnable {
	private ZonaEnergetica z;
	private List<Consumo> consumos;
	public int getIdZona() {return z.getIdZona();}

	
	public ProductorConsumos(ZonaEnergetica zona, List<Consumo> c) {
		// TODO Auto-generated constructor stub
		this.z=zona;
		this.consumos=c;
	}
//	PRODUCTOR DE CONSUMOS
	public void run() {		
		for(Consumo c:consumos) {
			z.getCentroControl().getBuffer().insertar(c);
		}
		z.getCentroControl().getBuffer().cambioVacio();
	}
}


