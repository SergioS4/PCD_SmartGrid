package main;

import energy.Consumo;
import energy.RedEnergetica;
import energy.ZonaEnergetica;

public class TramitesC implements Runnable{
//	Consumo c;
	ZonaEnergetica z;
	public TramitesC (/*Consumo consumo,*/ ZonaEnergetica zona) {
//		this.c=consumo;
		this.z=zona;
	}
	public void run() {
		try { Thread.sleep(200);		} catch (InterruptedException e) {e.printStackTrace();}
		while(z.getCentroControl().getBuffer().getTop()>0 && !z.getCentroControl().getBuffer().getVacio()
) {
			try { Thread.sleep(200);	} catch (InterruptedException e) {e.printStackTrace();}
			System.out.println("Dentro del while de tramitesC");
			z.tramitarConsumo(z);
		}
	}
}
