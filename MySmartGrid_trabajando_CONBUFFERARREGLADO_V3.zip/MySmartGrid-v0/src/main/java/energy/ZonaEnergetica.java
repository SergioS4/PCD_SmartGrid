package energy;

import operators.CentroControl;
import pcd.util.Ventana;
import storage.Bateria;

import java.awt.Color;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Objects;

import main.Config;

public class ZonaEnergetica {
    private final int idZona;
    private final CuentaEnergetica cuenta;
    private final Bateria bateria;
    private final CentroControl centroControl;
    private Ventana v;
    private final List<Consumo> consumoZona;

    public ZonaEnergetica(int idZona, CuentaEnergetica cuenta, Bateria bateria, CentroControl centroControl, Ventana _v) {
        this.idZona = idZona;
        this.cuenta = Objects.requireNonNull(cuenta);
        this.bateria = Objects.requireNonNull(bateria);
        this.centroControl = Objects.requireNonNull(centroControl);
        this.v = _v;
        this.consumoZona = new List<Consumo>() {
			
			@Override
			public <T> T[] toArray(T[] a) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public Object[] toArray() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public List<Consumo> subList(int fromIndex, int toIndex) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public int size() {
				// TODO Auto-generated method stub
				return 0;
			}
			
			@Override
			public Consumo set(int index, Consumo element) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public boolean retainAll(Collection<?> c) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean removeAll(Collection<?> c) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public Consumo remove(int index) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public boolean remove(Object o) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public ListIterator<Consumo> listIterator(int index) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public ListIterator<Consumo> listIterator() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public int lastIndexOf(Object o) {
				// TODO Auto-generated method stub
				return 0;
			}
			
			@Override
			public Iterator<Consumo> iterator() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public boolean isEmpty() {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public int indexOf(Object o) {
				// TODO Auto-generated method stub
				return 0;
			}
			
			@Override
			public Consumo get(int index) {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public boolean containsAll(Collection<?> c) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean contains(Object o) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public void clear() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public boolean addAll(int index, Collection<? extends Consumo> c) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public boolean addAll(Collection<? extends Consumo> c) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public void add(int index, Consumo element) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public boolean add(Consumo e) {
				// TODO Auto-generated method stub
				return false;
			}
		};
        
    }

    public int getIdZona() { return idZona; }
    public CuentaEnergetica getCuenta() { return cuenta; }
    public Bateria getBateria() { return bateria; }
    public CentroControl getCentroControl() { return centroControl; }
    //public List<Consumo> getConsumo() { return consumoZona; }

    
    public synchronized String tramitarConsumo(ZonaEnergetica z) {
    	
    	Consumo c=z.getCentroControl().getBuffer().extraer();

        if (c.getZona() != idZona) {
            return "ERROR: consumo dirigido a zona " + c.getZona() + " pero tramitado en zona " + idZona;
        }

        v.traza (c.getIdConsumo()+" solicita: "+c.getTotalKWh(), Color.BLUE);
        if(z.getBateria().getNivelActualKWh()<c.getTotalKWh()) {
        	recargarEnergia(z);
        }
        String resultado = centroControl.enviarTrabajo(c);
		System.out.println("CONSUMO " +c.getIdConsumo()+ " tramitado con exito");

        return resultado;
    }
    
    public synchronized void recargarEnergia(ZonaEnergetica z) {

        if (z.getIdZona() != idZona) {
            System.out.println("ERROR: Bateria de zona" + z.getIdZona() + " Se ha intendado cargar en la zona " + idZona);
        }
        bateria.carga(Config.CAPACIDAD_BATERIA);

    }

	@Override
    public String toString() {
        return "ZonaEnergetica{idZona=" + idZona + ", cuenta=" + cuenta + ", bateria=" + bateria + "}";
    }
    
    public Ventana getVentana () {
    	return v;
    }
    
    public void traza (String s) {
    	v.traza(s);
    }
    
    public void traza (String s, Color color) {
    	v.traza(s,color);
    }


}
