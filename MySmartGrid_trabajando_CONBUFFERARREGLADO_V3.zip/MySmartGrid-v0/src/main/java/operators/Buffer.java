package operators;

import energy.Consumo;

public class Buffer {
	private int top, capacity; 
	private Consumo vector[];
	private boolean vacio=false;
	public boolean getVacio() {return vacio;}
	public void cambioVacio() {vacio=true;
	}
	Buffer(int i) {
		top=0;
		capacity=i;
		vector = new Consumo[i];
	}
	
	synchronized public int getTop() {return top;}
	
	synchronized public Consumo extraer() {
		while(top==0) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		top--;
		notifyAll();
		
		return vector[top];
	}
	
	synchronized public void insertar(Consumo c) {
		while(top==capacity) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		vector[top]=c;
		top++;
		notifyAll();
		
	}
}
