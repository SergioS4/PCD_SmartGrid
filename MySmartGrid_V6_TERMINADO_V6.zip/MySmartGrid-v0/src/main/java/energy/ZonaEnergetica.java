package energy;

import operators.CentroControl;
import operators.RoboSol;
import operators.RoboViento;
import pcd.util.Ventana;
import storage.Bateria;
import storage.BateriaEolica;
import storage.BateriaSolar;
import storage.ContenedorBaterias;

import java.awt.Color;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Objects;
import java.util.concurrent.Semaphore;

import main.Config;

public class ZonaEnergetica {
    private final int idZona;
    private final CuentaEnergetica cuenta;
    private final Bateria bateria;
    private final BateriaEolica batEo;
    private final BateriaSolar batSol;
    private final CentroControl centroControl;
    private final RoboSol rSol;
    private final RoboViento rViento;
    private final ContenedorBaterias container;
    private Ventana v;
    private boolean vacia=false; 
    private boolean cargada=true;
    private final Semaphore barrier;
    private final Semaphore barrierTramites;

    

    public ZonaEnergetica(int idZona, CuentaEnergetica cuenta, Bateria bateria, CentroControl centroControl, Ventana _v) {
        this.idZona = idZona;
        this.cuenta = Objects.requireNonNull(cuenta);
        this.bateria = Objects.requireNonNull(bateria);
        this.centroControl = Objects.requireNonNull(centroControl);
        this.v = _v;
        this.container=new ContenedorBaterias();
        this.batEo = new BateriaEolica(Config.CAPACIDAD_BATERIA, 0, container);
        this.batSol = new BateriaSolar(Config.CAPACIDAD_BATERIA, 0, container);
        this.rSol=new RoboSol(container,this);
        this.rViento=new RoboViento(container,this);
        this.barrier=new Semaphore(0);
        this.barrierTramites=new Semaphore(Config.NUM_TRAMITES_POR_ZONA);
        
        
    }
    
    
    public int getIdZona() { return idZona; }
    public CuentaEnergetica getCuenta() { return cuenta; }
    public Bateria getBateria() { return bateria; }
    public CentroControl getCentroControl() { return centroControl; }
    synchronized public boolean getVacia() {return vacia;}
	synchronized public void cambioVacia() {vacia=true;}
	public Bateria getBatEo() { return batEo; }
	public Bateria getBatSol() { return batSol; }
	public RoboSol getRoboSol() { return rSol; }
	public RoboViento getRoboViento() { return rViento; }
	public Semaphore getBarrier() {return barrier;}
	public Semaphore getBarrierTramites() {return barrierTramites;}
	
	public void liberarBarrera(int numOperarios) {
		barrier.release(numOperarios);
	}
	
    //public List<Consumo> getConsumo() { return consumoZona; }

    
    public synchronized String tramitarConsumo(Consumo c) {
        if (c.getZona() != idZona) {
            return "ERROR: consumo dirigido a zona " + c.getZona() + " pero tramitado en zona " + idZona;
        }

        double demandaNormal=0;
        double demandaSol=0;
        double demandaViento=0;
        
        for(Demanda d:c.getDemandas()) {
        	if(d.getIdTipo().equals("SOLAR")) {
        		demandaSol+=d.getKWh();
        	}else if(d.getIdTipo().equals("EOLICA")) {
        		demandaViento+=d.getKWh();
        	}else {
				demandaNormal+=d.getKWh();
			}
        }
//        System.out.println("CONSUMO NORMAL --" +demandaNormal);
//        System.out.println("CONSUMO SOL --" +demandaSol);
//        System.out.println("CONSUMO VIENTO --" +demandaViento);
        
        
        v.traza (c.getIdConsumo()+" solicita: "+c.getTotalKWh(), Color.BLUE);
        while(bateria.getNivelActualKWh()<demandaNormal
        		||batEo.getNivelActualKWh()<demandaViento
        		||batSol.getNivelActualKWh()<demandaSol) {
        	cargada=false;
        	notifyAll();
        	try { wait(); } catch (InterruptedException e) {e.printStackTrace();}
        }
        
        
        
        
        String resultado = centroControl.enviarTrabajo(c,demandaNormal,demandaSol,demandaViento);
//		System.out.println("CONSUMO " +c.getIdConsumo()+ " tramitado con exito");
		notifyAll();
        return resultado;
    }
    
    public synchronized void recargarEnergia() {

        if (getIdZona() != idZona) {
            System.out.println("ERROR: Bateria de zona" + getIdZona() + " Se ha intendado cargar en la zona " + idZona);
        }
        while(cargada) {
        	try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        
        bateria.carga(Config.CAPACIDAD_BATERIA);
        cargada=true;
        notifyAll();

    }

	@Override
    public String toString() {
        return "ZonaEnergetica{idZona=" + idZona + ", cuenta=" + cuenta + ", bateria=" + bateria + "}";
    }
    
    public Ventana getVentana () {
    	return v;
    }
    
    public void traza (String s) {
    	v.traza(s);
    }
    
    public void traza (String s, Color color) {
    	v.traza(s,color);
    }


}
