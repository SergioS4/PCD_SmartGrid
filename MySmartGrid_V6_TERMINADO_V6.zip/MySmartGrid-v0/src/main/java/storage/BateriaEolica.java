package storage;

public class BateriaEolica extends Bateria{
	ContenedorBaterias container;

	public BateriaEolica(double capacidadMaxKWh, double nivelInicialKWh, ContenedorBaterias container) {
		super(capacidadMaxKWh, nivelInicialKWh);
		setTipoEnergia("EOLICA");
		this.container=container;
	}
	
	@Override
	public synchronized double suministra(double kWh) {
		try {
			return container.sacarCargaTipo(this.getTipoEnergia(), kWh);
		} catch (Exception e) {
			return 0;
		}
	}
	
	@Override
	public double getNivelActualKWh() {
		return container.getCargaViento();
	}

}
