package storage;

public class BateriaSolar extends Bateria{
	ContenedorBaterias container;

	public BateriaSolar(double capacidadMaxKWh, double nivelInicialKWh,ContenedorBaterias container) {
		super(capacidadMaxKWh, nivelInicialKWh);
		setTipoEnergia("SOLAR");
		this.container=container;
	}
	
	@Override
	public synchronized double suministra(double kWh) {
		try {
			return container.sacarCargaTipo(this.getTipoEnergia(), kWh);
		} catch (Exception e) {
			return 0;
		}
	}
	
	@Override
	public double getNivelActualKWh() {
		return container.getCargaSol();
	}

}
