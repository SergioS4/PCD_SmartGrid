package storage;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import main.Config;

public class ContenedorBaterias {
	private final double max;
	private double actualSol;
	private double actualViento;
	private Lock lockBaterias = new ReentrantLock();
	private Condition noHaySol=lockBaterias.newCondition();
	private Condition haySol=lockBaterias.newCondition();
	private Condition noHayViento=lockBaterias.newCondition();
	private Condition hayViento=lockBaterias.newCondition();
	
	
	public ContenedorBaterias( ) {
		actualSol=0;
		actualViento=0;
		max=Config.CAPACIDAD_BATERIA;
		
	}
	
	public void meterCarga(String tipo) {;
		
		lockBaterias.lock();
		try {
		if (tipo.equals("SOLAR")) {
			while(actualSol==max) {
			try {haySol.await();} catch (InterruptedException e) {e.printStackTrace();}
			}
			actualSol++;
			noHaySol.signalAll();
		}else {
			while(actualViento==max) {
				try {hayViento.await();} catch (InterruptedException e) {e.printStackTrace();}
				}
				actualViento++;
				noHayViento.signalAll();
		}
		}finally {
		lockBaterias.unlock();}
	}
	
	private void sacarSol(double carga) {
		actualSol-=carga;
	}

	public double getCargaSol() {
		lockBaterias.lock();
		try{return actualSol;}finally {
			lockBaterias.unlock();
		}
		
	}
	
	private void sacarViento(double carga) {
		 actualViento-=carga;
	}

	public double getCargaViento() {
		lockBaterias.lock();
		try{return actualViento;}finally {
			lockBaterias.unlock();
		}
	}
	 
	public double sacarCargaTipo(String tipo,double carga) {
		lockBaterias.lock();
		try{
			if(tipo.equals("SOLAR")&&actualSol<carga) {	
//			System.out.println("Sacando carga tipo "+tipo );
				try {
					noHaySol.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			sacarSol(carga);
			haySol.signalAll();
			
			}else if(actualViento<carga){	
//			System.out.println("Sacando carga tipo "+tipo );
				try {
					noHayViento.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			sacarViento(carga);
			hayViento.signalAll();
			}
			
			return carga;
			}finally {
				lockBaterias.unlock();
			}
	}

}
