package main;

import energy.Consumo;
import energy.RedEnergetica;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class MySmartGrid {
	
	
	public MySmartGrid() {
		
	}
	
	
	
    public static void main(String[] args) {
        RedEnergetica red = new RedEnergetica(
                Config.NUM_ZONAS,
                Config.CAPACIDAD_BATERIA,
                Config.NIVEL_INICIAL_BATERIA
        );
        
        List<Thread> tList = new ArrayList<Thread>();
        List<Consumo> consumos = Consumo.consumosDesdeFichero(Config.FICHERO_CONSUMOS);
        System.out.println("Leidos " + consumos.size() + " consumos desde " + Config.FICHERO_CONSUMOS);
        
      
       // Tramitamos los consumos de manera concurrente
       // String resultado;
        
       //Generamos los productores (recargan las baterias en un bucle infinito, se mantienen en espera hasta que les llegue un notify)
        for(int i=0; i<Config.NUM_ZONAS;i++) {
        	
        	//Creamos una nueva lista para cada zona, para separar los consumos exclusivos de cada zona
        	//Si la lista la hacemos de otra forma y usamos clear(), para reutilizarla la podemos borrar
        	List<Consumo> consumos2 = new ArrayList<Consumo>();
            for (Consumo c:consumos) {
            	if(c.getZona()==i) {
            		consumos2.add(c);
//            		System.out.println(c.getDireccion());
          	  	}
            }
        	ProductorConsumos productor = new ProductorConsumos(red.getZona(i),consumos2);
        	Thread hiloTramiteProductor = new Thread(productor);
        	hiloTramiteProductor.start();
        	Cargadores cargador = new Cargadores(red.getZona(i));
        	Thread hiloCargador = new Thread(cargador);
        	hiloCargador.start();
        }
        
        for(int i=0; i<Config.NUM_ZONAS;i++) {
    		for(int j=0;j<Config.NUM_OPERARIOS_POR_ZONA;j++) {
    			TramitesC tramite = new TramitesC(red.getZona(i));
    			Thread hiloTramiteConsumidor = new Thread(tramite);
    			hiloTramiteConsumidor.start();
    			tList.add(hiloTramiteConsumidor);
            }
        }
        
        for(int i=0; i<Config.NUM_ZONAS;i++) {
        	red.getZona(i).liberarBarrera(Config.NUM_OPERARIOS_POR_ZONA);
        }
        
        for (Thread tl:tList) {
        	try {
				tl.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
     
        // Ahora las autorias se van a hacer por Stream 
        red.imprimeAuditoria();
       
        
        
       //Streams VERSION  4
        Stream<Consumo>consum=consumos.stream();
       
        consum
       	.parallel()
       	.filter(d->d.getTotalKWh()<5)
       	.forEach(d->System.out.println(d.getIdConsumo()));
       
        consum=consumos.stream();
       
        Optional<Double> mayorCon=consum
        		.parallel()
        		.map(Consumo::getTotalKWh)
        		.reduce((a,b)->a<b?b:a);
        System.out.println("El mayor precio es: "+ mayorCon);
       
        consum=consumos.stream();
       
        consum
        .parallel()
        .filter(d->d.getDireccion().contains("Sagitario, 24"))
        .findAny()
        .ifPresentOrElse(d->System.out.println(d.getDireccion()),()->System.out.println("No encontrado"));
       
        consum=consumos.stream();
       
        consum
        .parallel()
        .filter(d->d.getDireccion().contains("Berna, 11"))
        .findAny()
        .ifPresentOrElse(d->System.out.println(d.getDireccion()),()->System.out.println("No encontrado"));
       
      
    }

}
