package main;

import energy.Consumo;
import energy.ConsumoPendiente;
import energy.RedEnergetica;
import energy.ZonaEnergetica;

public class TramitesC implements Runnable{
//	Consumo c;
	ZonaEnergetica z;
	public TramitesC (/*Consumo consumo,*/ ZonaEnergetica zona) {
//		this.c=consumo;
		this.z=zona;
	}
	public void run() {
//		while(!z.getVacia() && z.getCentroControl().getBuffer().getTop()>0 && !z.getCentroControl().getBuffer().getVacio()) {
//			z.tramitarConsumo(z);
//		}
		
		while(true) {
			ConsumoPendiente cPend=z.getCentroControl().getBuffer().extraer();
			if(cPend==null) {
				break;
			}
			Consumo c=cPend.getConsumo();
			try {
				z.getBarrierTramites().acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			z.tramitarConsumo(c);
			z.getBarrierTramites().release();
			cPend.finaliza();
		}
	}
}
