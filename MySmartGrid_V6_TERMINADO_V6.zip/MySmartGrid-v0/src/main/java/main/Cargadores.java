package main;

import energy.ZonaEnergetica;

public class Cargadores implements Runnable{
	private ZonaEnergetica z;
	public Cargadores(ZonaEnergetica zona) {
		this.z=zona;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		//Lanza las baterias eolicas y solares y luego se queda cargando la normal
		Thread hiloSol = new Thread(z.getRoboSol());
    	hiloSol.start();
    	Thread hiloViento = new Thread(z.getRoboViento());
    	hiloViento.start();
		while(!z.getVacia()) {
			z.recargarEnergia();
		}
		
	}

}
