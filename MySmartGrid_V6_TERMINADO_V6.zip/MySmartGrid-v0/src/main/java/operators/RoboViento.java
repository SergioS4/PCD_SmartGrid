package operators;

import storage.Bateria;
import storage.BateriaEolica;
import storage.ContenedorBaterias;
import energy.ZonaEnergetica;


	public class RoboViento implements Runnable {
		ContenedorBaterias contBateria;
		ZonaEnergetica z;
		public RoboViento(ContenedorBaterias container,ZonaEnergetica zona) {
			this.contBateria=container;	
			this.z=zona;
		}
		
		
		public void run() {
			while (true) {
				contBateria.meterCarga("EOLICA");
			}
		}
		
	}
	
