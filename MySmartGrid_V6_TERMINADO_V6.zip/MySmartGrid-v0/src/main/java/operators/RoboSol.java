package operators;

import energy.ZonaEnergetica;
import storage.Bateria;
import storage.BateriaSolar;
import storage.ContenedorBaterias;

public class RoboSol implements Runnable{
	ZonaEnergetica z;
	private final ContenedorBaterias contBateria;
	public RoboSol(ContenedorBaterias container,ZonaEnergetica zona) {
		this.contBateria=container;	
		this.z=zona;
	}
	
	public void run() {
		while (true) {
			contBateria.meterCarga("SOLAR");
		}
	}
}
